from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA_PATH = Path('data/tf_version_benchmarks_template.csv')
OUT_DIR = Path('imgs_new')


def main() -> None:
    df = pd.read_csv(DATA_PATH)
    required = {'metric', 'tf_2_15', 'tf_2_18', 'unit'}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f'Missing columns: {sorted(missing)}')

    if df[['tf_2_15', 'tf_2_18']].isnull().any().any():
        raise ValueError(
            'The benchmark CSV still contains empty values. '
            'Fill in tf_2_15 and tf_2_18 before generating the plots.'
        )

    OUT_DIR.mkdir(parents=True, exist_ok=True)

    labels = {'mean_runtime_per_cycle': 'Mean runtime per cycle', 'runtime_std': 'Runtime standard deviation'}
    filenames = {'mean_runtime_per_cycle': 'tf_runtime_mean_barplot.png', 'runtime_std': 'tf_runtime_std_barplot.png'}
    colors = ['#4C78A8', '#F58518']

    for _, row in df.iterrows():
        metric = row['metric']
        values = [row['tf_2_15'], row['tf_2_18']]
        fig, ax = plt.subplots(figsize=(6, 4))
        bars = ax.bar(['TensorFlow 2.15', 'TensorFlow 2.18'], values, color=colors)
        ax.set_ylabel(row['unit'])
        ax.set_title(labels.get(metric, metric.replace('_', ' ').title()))
        ax.grid(axis='y', alpha=0.25)
        ax.set_axisbelow(True)

        ymax = max(values) if max(values) > 0 else 1
        ax.set_ylim(0, ymax * 1.2)

        for bar, value in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + ymax * 0.03,
                f'{value:.4g}',
                ha='center',
                va='bottom',
                fontsize=10,
            )

        fig.tight_layout()
        fig.savefig(OUT_DIR / filenames.get(metric, f'{metric}.png'), dpi=200)
        plt.close(fig)


if __name__ == '__main__':
    main()