from abc import ABC, abstractmethod
from dataclasses import dataclass
import onnxruntime as ort
from enum import Enum
import os

class Architecture(Enum):
    ALL = 0
    CPU = 1
    CUDA = 2
    TENSOR = 3    

ARCHS = {
    Architecture.CPU: ['CPUExecutionProvider',],
    Architecture.CUDA: ['CUDAExecutionProvider',],
    Architecture.TENSOR: ['TensorrtExecutionProvider',],
    Architecture.ALL: ort.get_available_providers()
}

@dataclass
class ONNXModel(ABC):
    model_name: str
    model_folder: str = None

    def __post_init__(self, arch=Architecture.CPU):
        if not self.model_folder:
            self.model_folder = os.getcwd()

        self.storage_path = os.path.join(self.model_folder, self.model_name)
        self._read_onnx(arch)

    def _read_onnx(self, arch):
        self.model = ort.InferenceSession(self.storage_path, providers=ARCHS[arch])
        self.sess = self.model
        self.outputs = [output.name for output in self.sess.get_outputs()]
        self.inputs_keys = [iinput.name for iinput in self.sess.get_inputs()]

    @abstractmethod
    def __call__(self, input_vector):
        pass