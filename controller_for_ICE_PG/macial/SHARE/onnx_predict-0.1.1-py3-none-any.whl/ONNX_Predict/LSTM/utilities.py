from tensorflow.keras.models import load_model # type: ignore

def get_model(m_path):
    return load_model(m_path, compile=False)

def get_initial_states(model, y_scaled_ini, out_format='tensor'):
    states = []
    saved = []

    for layer in model.get_config()['layers']:
        if layer['class_name'] == 'LSTM':
            name = layer['config']['name']
            hidden = 'h'+ name[1:None]
            cell = 'c'+ name[1:None]

            if hidden not in saved and cell not in saved:
                states.append(model.get_layer(hidden)(y_scaled_ini))
                states.append(model.get_layer(cell)(y_scaled_ini))
                saved += [hidden, cell]

    if out_format.lower() == 'tensor':
        return states
    elif out_format.lower() == 'array':
        return [value.numpy() for value in states]
    else:
        raise ValueError(f'Output format {out_format} not implemented')