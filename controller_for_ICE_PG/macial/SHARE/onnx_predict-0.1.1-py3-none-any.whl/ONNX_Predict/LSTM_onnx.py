from .ONNXmodel import ONNXModel, Architecture
from .LSTM.utilities import get_model, get_initial_states
from dataclasses import dataclass
import numpy as np
import os

@dataclass
class LSTM_onnx(ONNXModel):
    model_name: str
    model_folder: str = None
    tf_model_name: str = None
    arch: Architecture = Architecture.CPU

    def __post_init__(self):
        super().__post_init__(self.arch)

        self.initial_states = False
        if self.tf_model_name:
            tf_model_path = os.path.join(self.model_folder, self.tf_model_name)
            self.tf_model = get_model(tf_model_path)

    def __call__(self, input_vector):
        return self.predict(input_vector)

    def __define_initial_states(self, y_scaled_ini, out_format='array'):
        if not hasattr(self, 'tf_model'):
            raise AttributeError('TensorFlow model not loaded. Cannot get initial states.')
        if self.initial_states:
            raise AttributeError('Initial states already defined.')

        self.initial_states = True
        return get_initial_states(self.tf_model, y_scaled_ini, out_format)

    def __check_inputs(self, input_vector):
        is_ok = True
        for iinput in input_vector:
            is_ok *= isinstance(iinput,(np.ndarray, np.generic))

        if not is_ok:
            raise TypeError('Input vector must be a list or tuple of numpy arrays.')

    def __onnx_run(self, input_vector):
        if not (isinstance(input_vector, (list, tuple))):# or isinstance(input_vector, tuple)):
            input_vector = [input_vector, ]

        self.__check_inputs(input_vector)
    
        inputs = {key:value for key, value in zip(self.inputs_keys, input_vector)}
        
        pred = self.sess.run(self.outputs, inputs)
        self.states = pred[1:]
        return pred[:1]

    def predict(self, input_vector):
        if not self.initial_states:
            self.states = self.__define_initial_states(input_vector[1], out_format='array')
        
        return self.__onnx_run(input_vector+self.states)
    
    def reset_states(self):
        self.states = None
        self.initial_states = None