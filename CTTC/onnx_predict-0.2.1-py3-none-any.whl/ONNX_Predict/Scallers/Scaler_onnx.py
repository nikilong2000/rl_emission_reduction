from ..ONNXmodel import ONNXModel, Architecture
from dataclasses import dataclass
import numpy as np

@dataclass
class Scaler_onnx(ONNXModel):
    model_name: str
    model_folder: str = None
    inv_model: object = None
    arch: Architecture = Architecture.CPU

    def __post_init__(self):
        super().__post_init__(self.arch)

    def __call__(self, input_vector):
        raise NotImplementedError('Callable function not implemented for scalers types')

    def __check_inputs(self, input_vector):
        is_ok = True
        for iinput in input_vector:
            is_ok *= isinstance(iinput,(np.ndarray, np.generic))

        if not is_ok:
            raise TypeError('Input vector must be a list or tuple of numpy arrays.')

    def __onnx_run(self, input_vector):
        if not (isinstance(input_vector, (list, tuple))):# or isinstance(input_vector, tuple)):
            input_vector = [input_vector, ]

        self.__check_inputs(input_vector)
    
        inputs = {key:value for key, value in zip(self.inputs_keys, input_vector)}
        
        pred = self.sess.run(self.outputs, inputs)
        return pred[0]

    def transform(self, input_vector):
        return self.__onnx_run(input_vector)
    
    def inverse_transform(self, input_vector):
        if self.inv_model:
            return self.inv_model.transform(input_vector)
        else:
            raise ValueError('Inverse transform model not provided')
 