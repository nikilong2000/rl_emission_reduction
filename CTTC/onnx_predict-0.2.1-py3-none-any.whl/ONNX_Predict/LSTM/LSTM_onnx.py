from ..ONNXmodel import ONNXModel, Architecture
from ._utilities import __get_model, __get_initial_states, Keras
from dataclasses import dataclass
import numpy as np
import os

@dataclass
class LSTM_onnx(ONNXModel):
    model_name: str
    model_folder: str = None
    tf_model_name: str = None
    arch: Architecture = Architecture.CPU
    keras_version: int = 3

    def __post_init__(self):
        super().__post_init__(self.arch)

        self.output_names = self.outputs
        self.__initial_states = False if 'init' not in self.model_name else True
        self.__states = []

        if self.tf_model_name:
            tf_model_path = os.path.join(self.model_folder, self.tf_model_name)
            self.tf_model = __get_model(tf_model_path)

    def __call__(self, input_vector):
        return self.predict(input_vector)

    def __define_initial_states(self, y_scaled_ini, out_format='array'):
        if self.__initial_states:
            raise AttributeError('Initial states already defined.')
        
        match self.keras_version:
            case Keras.Keras_2:
                if not hasattr(self, 'tf_model_name'):
                    raise AttributeError('TensorFlow model not loaded. Cannot get initial states.')
            case Keras.Keras_3:
                raise AttributeError(f'Initial states not define for model {self.model_name}')
            case default:
                raise ValueError(f'Keras version {self.keras_version} not defined')

        init_states = __get_initial_states(self.tf_model, y_scaled_ini[1], out_format, self.keras_version)
        self.__initial_states = True
        
        return init_states

    def __check_inputs(self, input_vector):
        is_ok = True
        for iinput in input_vector:
            is_ok *= isinstance(iinput,(np.ndarray, np.generic))

        if not is_ok:
            raise TypeError('Input vector must be a list or tuple of numpy arrays.')

    def __onnx_run(self, input_vector):
        if not (isinstance(input_vector, (list, tuple))):# or isinstance(input_vector, tuple)):
            input_vector = [input_vector, ]

        self.__check_inputs(input_vector)
        input_vector = input_vector + self.__states

        inputs = {key:value for key, value in zip(self.inputs_keys, input_vector)}
        
        pred = self.sess.run(self.outputs, inputs)

        if 'init' not in self.model_name:
            self.__states = pred[1:]
            return pred[0]
        else:
            return pred

    def predict(self, input_vector):
        if not self.__initial_states:
            self.__states = self.__define_initial_states(input_vector, out_format='array')

        return self.__onnx_run(input_vector)
    
    def reset_states(self):
        self.__states = None
        self.__initial_states = None

    def set_states(self, states):
        self.__states = states

    def set_initial_states_status(self, status):
        self.__initial_states = status