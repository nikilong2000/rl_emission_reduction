from .LSTM.LSTM_onnx import LSTM_onnx
from .Scallers.Scaler_onnx import Scaler_onnx

def load_network(directory, 
                 input_scaler_name='input_scaler', 
                 output_scaler_name='output_scaler',
                 output_inv_scaler_name='output_scaler_inv',
                 extension='onnx'):
    
    tail = '.' + extension
    
    # ---- Load models and scalers ----
    main_model      = LSTM_onnx('main'+tail, directory)
    init_model      = LSTM_onnx('init'+tail, directory)
    in_scaler       = Scaler_onnx(input_scaler_name + tail, directory)
    out_inv_scaler  = Scaler_onnx(output_inv_scaler_name + tail, directory)
    out_scaler      = Scaler_onnx(output_scaler_name + tail, directory, inv_model=out_inv_scaler)

    # ---- Models info ----
    print(f"Input_Shape Main:", main_model.sess.get_inputs()[0].shape)
    for i, layer in enumerate(main_model.inputs_keys):
        if 'h_m' not in layer and 'c_m' not in layer:
            print(f"\t{i:02d}: {layer}")

    print(f"\nInput_Shape Init:", init_model.sess.get_inputs()[0].shape)
    for i, layer in enumerate(init_model.inputs_keys):
        print(f"\t{i:02d}: {layer}")

    return (
        main_model,
        init_model,
        in_scaler,
        out_scaler,
        main_model.predict,
        init_model.predict,
    )

def set_states(main_model, states_dict):
    initial_states = list(states_dict.values())
    main_model.set_states(initial_states)
    main_model.set_initial_states_status(True)